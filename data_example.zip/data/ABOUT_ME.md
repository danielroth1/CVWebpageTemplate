<linkedin href="https://www.linkedin.com/in/your-handle">LinkedIn</linkedin>

### About Me
Write a short paragraph about yourself here. Mention your core strengths, experience level, and what you enjoy building.

- Highlight your primary stack (e.g., <skill>Your Front‑End Tech</skill>, <skill>Your Backend Tech</skill>)
- Add a note about collaboration, leadership, or impact you deliver
- Optionally include tools you use daily (e.g., <skill>Your DevOps Tool</skill>)

You can also mention learning goals or interests (e.g., integrating **AI** tools into your workflow) if relevant.