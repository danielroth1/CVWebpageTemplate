Have questions or want to get in touch? Use the email button below.

- Job opportunities
- Collaboration ideas
- Open‑source contributions
- Technical questions

<email>Send Email</email>

Response time (optional): e.g., "I typically reply within 1–2 business days."
