<website href="https://your-project-website.example">Visit Website</website>
<github href="https://github.com/your-handle/your-repo">View on GitHub</github>
<linux href="https://github.com/your-handle/your-repo/releases/download/0.1/linux.AppImage">Download for Linux</linux> <windows href="https://github.com/your-handle/your-repo/releases/download/0.1/windows.zip">Download for Windows</windows>
<macos href="https://github.com/your-handle/your-repo/releases/download/0.1/macos.dmg">Download for macOS</macos>

Replace this text with a concise overview of your project: what it does, who it's for, and why it matters.

### Highlights
- Built with <skill>Your Tech A</skill> and <skill>Your Tech B</skill>
- Key feature 1: Short description
- Key feature 2: Short description

### Quick Start
1. Prerequisite A
2. Installation or usage step

### Screenshots (optional)
Add images like this:
<img src="ExampleProject1/preview.jpg" width="300"/>

### Videos (optional)
Add videos like this:
<webm src="ExampleProject1/preview.mp4" start="1" max-width="300" />

Add youtube videos like this:
<youtube id="xlMe7Q1j4Lc" title="Intro" width="300"  /><br>

### Downloads (optional)
<download href="https://example.com/your-download">Download</download>

