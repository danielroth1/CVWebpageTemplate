<website href="https://your-project-website.example">Visit Website</website>
<github href="https://github.com/your-handle/your-repo">View on GitHub</github>
<firefox href="https://addons.mozilla.org/de/firefox/addon/your-addon/">Add to Firefox</firefox>
<chrome href="https://addons.mozilla.org/de/firefox/addon/your-addon/">Add to Chrome</chrome>

Replace this text with a concise overview of your project: what it does, who it's for, and why it matters.

### Highlights
- Built with <skill>Your Tech A</skill> and <skill>Your Tech B</skill>
- Key feature 1: Short description
- Key feature 2: Short description

### Quick Start
1. Prerequisite A
2. Installation or usage step

### Screenshots (optional)
Add images like this:
<img src="ExampleProject2/preview.jpg" width="300"/>

### Videos (optional)
Add videos like this:
<webm src="ExampleProject2/preview.mp4" start="1" max-width="300" />

### Downloads (optional)
<download href="https://example.com/your-download">Download</download>

